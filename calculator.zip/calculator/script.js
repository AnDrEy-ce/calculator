// "use strcit"
document.querySelectorAll('.btn').forEach(item => {
    item.addEventListener('click',show)
})
document.addEventListener('keydown',showkey)


let num = [];
let symbol = 0;
let numOne = '';
let numTwo = '';
let Symbol = '';

// для ввода через экран

function show(event) {
    symbol = event.target.value;
    switch (symbol) {
        case 'C':
            document.querySelector('#result').value = ``;
            num.splice(0,num.length)
            numOne = '';
            numTwo = '';
        break;
        case '+':
            if((num.length != 0) || (numOne != '')){
                document.querySelector('#result').value = `${event.target.value}`;
                if (numOne === ''){
                numOne = num.join(''); 
                }
                num.splice(0,num.length);
                Symbol = '+';
            }else{

            }  
        break;
        case '-':
            if((num.length != 0) || (numOne != '')){
             document.querySelector('#result').value = `${event.target.value}`;
            if (numOne === ''){
               numOne = num.join(''); 
            }
            num.splice(0,num.length);
            Symbol = '-';
            }else{}  
          
        break;
        case '/':
            if((num.length != 0) || (numOne != '')){
            document.querySelector('#result').value = `${event.target.value}`;
            if (numOne === ''){
               numOne = num.join(''); 
            }
            num.splice(0,num.length);
            Symbol = '/';
            }else{} 
           
        break;
        case '*':
            if((num.length != 0) || (numOne != '')){
            document.querySelector('#result').value = `${event.target.value}`;
            if (numOne === ''){
               numOne = num.join(''); 
            }
            num.splice(0,num.length);
            Symbol = '*';
            }else{} 
           
        break;
        case '.':
            if((num.length != 0) || (numOne != '')){
                if(num.length != 0){
                    if(num.find(item => {return item == '.'}) == undefined){
                    num.push(event.target.value);
                    document.querySelector('#result').value = num.join('')
                }else{}
                }
            }else{} 
        break;
        case '1':
            num.push(event.target.value);
            if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
             
        break;
        case '2':
            num.push(event.target.value);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case '3':
            num.push(event.target.value);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case '4':
            num.push(event.target.value);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case '5':
            num.push(event.target.value);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case '6':
            num.push(event.target.value);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case '7':
            num.push(event.target.value);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case '8':
            num.push(event.target.value);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case '9':
            num.push(event.target.value);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case '0':
             num.push(event.target.value);
             if((num[0] == 0) && (num[1] == 0)){
                 num.splice(0,1);
                 document.querySelector('#result').value = num.join('')
             }else{
                document.querySelector('#result').value = num.join('')
             }
        break;
        case '=':
            if(numOne == ''){
                numOne ='';
                numTwo = '';
                document.querySelector('#result').value = ""
                
            }else{
                 numTwo = num.join('');
            if (Symbol == '/' && numTwo == 0){
                document.querySelector('#result').value = "Ошибка"
            }else{
                document.querySelector('#result').value = eval(numOne + Symbol + numTwo);
                Symbol = '';
                numOne = document.querySelector('#result').value; 
                num.splice(0,num.length);
            }
            }
           
        break;
    }
}

// для ввода с клавы

function showkey(event) {
    symbol = window.event.keyCode;
    switch (symbol) {
         case 187:
             if((num.length != 0) || (numOne != '')){
                if(event.shiftKey == true){
                    document.querySelector('#result').value = `${window.event.key}`;
            if (numOne === ''){
               numOne = num.join(''); 
           }
           num.splice(0,num.length);
            Symbol = '+';
            }else{}
                if (numOne === ''){
                numOne = num.join(''); 
                }
                num.splice(0,num.length);
                Symbol = '+';
            }else{

            }  
        break;
         case 189:
             if((num.length != 0) || (numOne != '')){
                document.querySelector('#result').value = `${window.event.key}`;
                if (numOne === ''){
                   numOne = num.join(''); 
                }
                num.splice(0,num.length);
                Symbol = '-';
               if (numOne === ''){
                  numOne = num.join(''); 
               }
               num.splice(0,num.length);
               Symbol = '-';
               }else{}  
         break;
         case 191:
           



             if((num.length != 0) || (numOne != '')){
                document.querySelector('#result').value = `${window.event.key}`;
                if (numOne === ''){
                   numOne = num.join(''); 
                }
                num.splice(0,num.length);
                Symbol = '/';
                if (numOne === ''){
                   numOne = num.join(''); 
                }
                num.splice(0,num.length);
                Symbol = '/';
                }else{} 
         break;
        case 56:
         if(event.shiftKey == true){
                 document.querySelector('#result').value = `${window.event.key}`;
             if (numOne === ''){
                numOne = num.join(''); 
             }
             num.splice(0,num.length);
             Symbol = '*';
             }else{
                 num.push(8);
                 if((num[0] == 0) && (num[1] != ".")){
                 num.splice(0,1);
                 document.querySelector('#result').value = num.join('')
             }else{
                 document.querySelector('#result').value = num.join('')
             } 
             }
         break;
        case 190:
            if((num.length != 0) || (numOne != '')){
                if(num.length != 0){
                    if(num.find(item => {return item == '.'}) == undefined){
                    num.push(window.event.key);
                    document.querySelector('#result').value = num.join('')
                }else{}
                }
            }else{} 
        break;
        case 49:
            num.push(1);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case 50:
            num.push(2);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case 51:
            num.push(3);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case 52:
            num.push(4);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case 53:
            num.push(5);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case 54:
            num.push(6);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case 55:
            num.push(7);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;        
        case 57:
            num.push(9);
             if((num[0] == 0) && (num[1] != ".")){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
                document.querySelector('#result').value = num.join('')
            }
        break;
        case 48:
            num.push(0);
            if((num[0] == 0) && (num[1] == 0)){
                num.splice(0,1);
                document.querySelector('#result').value = num.join('')
            }else{
               document.querySelector('#result').value = num.join('')
            }
        break;
        case 13:
            if(numOne == ''){
                numOne ='';
                numTwo = '';
                document.querySelector('#result').value = ""   
            }else{
                 numTwo = num.join('');
            if (Symbol == '/' && numTwo == 0){
                document.querySelector('#result').value = "Ошибка"
            }else{
                document.querySelector('#result').value = eval(numOne + Symbol + numTwo);
                Symbol = '';
                numOne = document.querySelector('#result').value; 
                num.splice(0,num.length);
            }
            }
        break;
        case 8:
            num.splice(num.length-1,1);
            document.querySelector('#result').value = num.join('');
        break;

    }


  
}